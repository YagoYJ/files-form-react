import FileForm from './components/FileForm';
import './app.css';

function App() {
  return (
    <div className="App">
      <FileForm />
    </div>
  );
}

export default App;
