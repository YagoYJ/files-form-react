import styled from 'styled-components';

export const FormContainer = styled.form`
  width: 90%;
  max-width: 1000px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 20px;
  background-color: #ffffff;
  border: 1px solid #000000;
  border-radius: 8px;
  margin: auto;
`;

export const InputGroup = styled.div`
  width: 100%;
  margin-bottom: 15px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
`;

export const InputLabel = styled.label`
  margin-bottom: 5px;
`;
