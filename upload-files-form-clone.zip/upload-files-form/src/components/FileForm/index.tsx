import { ChangeEvent, FormEvent, useState } from 'react';
import { FormContainer, InputGroup, InputLabel } from './styles';

export default function FileForm() {
  const [bannerSite, setBannerSite] = useState<File>();
  const [previewSite, setPreviewSite] = useState('');
  const [bannerMobile, setBannerMobile] = useState<File>();
  const [previewMobile, setPreviewMobile] = useState('');

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    console.log('Site:');
    console.log(bannerSite);
    console.log('Mobile:');
    console.log(bannerMobile);
  }

  function handleSelectBannerSite(event: ChangeEvent<HTMLInputElement>) {
    if (!event.target.files) {
      return;
    }

    const selectedImage = event.target.files[0];

    setBannerSite(selectedImage);

    const selectedImagePreview = URL.createObjectURL(selectedImage);

    setPreviewSite(selectedImagePreview);
  }

  function handleSelectBannerMobile(event: ChangeEvent<HTMLInputElement>) {
    if (!event.target.files) {
      return;
    }

    const selectedImage = event.target.files[0];

    setBannerMobile(selectedImage);

    const selectedImagePreview = URL.createObjectURL(selectedImage);

    setPreviewMobile(selectedImagePreview);
  }

  return (
    <FormContainer encType="multipart/form-data" onSubmit={handleSubmit}>
      <InputGroup>
        <InputLabel htmlFor="bannerSite">Banner para o site</InputLabel>
        {previewSite && <img src={previewSite} alt="Banner para o site" />}

        <input
          type="file"
          onChange={handleSelectBannerSite}
          name="bannerSite"
          id="bannerSite"
          accept="image/*"
        />
      </InputGroup>
      <InputGroup>
        <InputLabel htmlFor="bannerMobile">Banner para o Aplicativo</InputLabel>
        {previewMobile && (
          <img src={previewMobile} alt="Banner para o mobile" />
        )}
        <input
          type="file"
          onChange={handleSelectBannerMobile}
          name="bannerMobile"
          id="bannerMobile"
          accept="image/*"
        />
      </InputGroup>
      <button type="submit">Enviar</button>
    </FormContainer>
  );
}
